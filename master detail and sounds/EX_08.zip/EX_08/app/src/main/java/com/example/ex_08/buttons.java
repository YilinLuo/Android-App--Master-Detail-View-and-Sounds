package com.example.ex_08;

/****************************************************************************
 *
 * This is the model class for making list items of sound buttons
 *
 *
 *****************************************************************************/

public class buttons {
    private String button_name;

    public String getButton_name() {
        return button_name;
    }

    public void setButton_name(String button_name) {
        this.button_name = button_name;
    }

    public buttons(String button_name){
        this.button_name = button_name;
    }


}
