package com.example.ex_08;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class displayFragment extends Fragment {
    public static TextView info;
    public String TAG = "THE CLICKED BUTTON IS: ";
    public displayFragment(){

    }
    @Override
    public void onCreate(Bundle state){
        super.onCreate(state);
        setRetainInstance(true);

    }

    public void messageSentBack(CharSequence message){
        if(message != null)
            info.setText(message.toString());
        Log.d(TAG,"THE STRING IS "+ message);
    }

   @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.information_fragment,container,false);
        info = v.findViewById(R.id.info);
        return v;
    }

}
