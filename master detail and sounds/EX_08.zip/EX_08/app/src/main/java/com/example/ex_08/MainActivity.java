package com.example.ex_08;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements customAdapter.button_pressed{


    private static final String TAG = "Yilin";
    boolean master_view;
    public list_fragment listFrag = new list_fragment();
    public static TextView changeText;


    /****************************************************************************
    *
    * button_pressed(String button_info) is an interface method
    * that is called by listfragment to
    * executed through the FragmentManager in Main, then detail fragment (displayfragment)
    *is called when dual panel is true.
    ****************************************************************************
     */

/*This makes sure that the information of pressed button is sent to
   detail fragment to display the sound currently playing.
  */
    @Override
    public void button_pressed(String button_info){
        displayFragment display = (displayFragment) getSupportFragmentManager().findFragmentById(R.id.display_container);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.details, display);
        fm.commit();
        display.messageSentBack(button_info);
    }

/****************************************************************************
*The rest of these are regular MainActivity methods
*
*
*****************************************************************************
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getSupportFragmentManager();
        fm.beginTransaction().replace(R.id.container_listfrag, new list_fragment()).commit();
        Log.d(TAG,"YES, ListFragment is attached");

        changeText = findViewById(R.id.change_text_onSelection);
        if (customAdapter.currentPlaying != null && list_fragment.dualPane == false) {
                changeText.setText(customAdapter.currentPlaying);
                Toast.makeText(getApplicationContext(),"IS PLAYING"+customAdapter.currentPlaying,Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onSaveInstanceState(final Bundle savedInstanceState) {

        super.onSaveInstanceState(savedInstanceState);

        Log.d(TAG, "on saved");
    }


    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(TAG, "onStop(Bundle) called" );
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(TAG, "onResume(Bundle) called" );

    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(TAG, "onPause(Bundle) called" );

    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d(TAG, "onStart(Bundle) called" );

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy(Bundle) called" );

    }



}
