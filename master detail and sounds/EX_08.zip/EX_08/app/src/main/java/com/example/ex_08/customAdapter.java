package com.example.ex_08;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

public class customAdapter extends ArrayAdapter {

    public static String TAG = "Onclick";
    public static String description_text;
    public List items;
    public Context context;
    public static String currentPlaying;
    public button_pressed button_triggered;

    public list_fragment listFrag = new list_fragment();

    /*public Integer toPlay = 1;
    public MediaPlayer player = MediaPlayer.create(getContext(),toPlay);
*/
    public customAdapter(Context c, List items){
        super(c,0,items);
        this.context = c;
        this.items = items;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    @Override
    public boolean isEnabled(int position) {
        return true;
    }

    public View getView(int position, View layout2, ViewGroup parent){

        View layout = layout2;

        if(layout == null){
            LayoutInflater inflater = LayoutInflater.from(getContext());
            layout = inflater.inflate(R.layout.list_fragment_row, parent, false);
        }

        buttons button_text = (buttons) getItem(position);

        final Button sound_button = layout.findViewById(R.id.sound_button);
        sound_button.setText(button_text.getButton_name());

        sound_button.setOnClickListener(new View.OnClickListener(){
            @Override
        public void onClick(View view ){
                String button_text = sound_button.getText().toString();


                switch(button_text){
                    case "music1":
                       MediaPlayer mediaPlayer = MediaPlayer.create(getContext(), R.raw.music1);
                        mediaPlayer.start();
                        currentPlaying = "MUSIC1";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC1 IS PLAYING");}

                        Toast.makeText(getContext(),"IS PLAYING MUSIC1",Toast.LENGTH_LONG).show();

                        if(button_triggered != null){

                         button_triggered.button_pressed("music1");
                        }

                     /*  toPlay = R.raw.music1;
                       player.start();*/
                        break;
                    case "music2":
                       MediaPlayer mediaPlayer2 = MediaPlayer.create(getContext(), R.raw.music2);
                        mediaPlayer2.start();
                        currentPlaying = "MUSIC2";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC2 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC2",Toast.LENGTH_LONG).show();

                        if(button_triggered != null){

                            button_triggered.button_pressed("music2");
                        }
                        break;

                    case "music3":
                        MediaPlayer mediaPlayer3 = MediaPlayer.create(getContext(), R.raw.music3);
                        mediaPlayer3.start();
                        currentPlaying = "MUSIC3";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC3 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC3",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music3");
                        }
                        break;

                    case "music4":
                        MediaPlayer mediaPlayer4 = MediaPlayer.create(getContext(), R.raw.music4);
                        mediaPlayer4.start();
                        currentPlaying = "MUSIC4";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC4 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC4",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music4");
                        }
                        break;
                    case "music5":
                        MediaPlayer mediaPlayer5 = MediaPlayer.create(getContext(), R.raw.music5);
                        mediaPlayer5.start();
                        currentPlaying = "MUSIC5";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC5 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC5",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music5");
                        }
                        break;

                    case "music6":
                        MediaPlayer mediaPlayer6 = MediaPlayer.create(getContext(), R.raw.music6);
                        mediaPlayer6.start();
                        currentPlaying = "MUSIC6";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC6 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC6",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music6");
                        }
                        break;
                    case "music7":
                        MediaPlayer mediaPlayer7 = MediaPlayer.create(getContext(), R.raw.music7);
                        mediaPlayer7.start();
                        currentPlaying = "MUSIC7";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC7 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC7",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music7");
                        }
                        break;

                    case "music8":
                        MediaPlayer mediaPlayer8 = MediaPlayer.create(getContext(), R.raw.music8);
                        mediaPlayer8.start();
                        currentPlaying = "MUSIC8";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC8 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC8",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music8");
                        }
                        break;
                    case "music9":
                        MediaPlayer mediaPlayer9 = MediaPlayer.create(getContext(), R.raw.music9);
                        mediaPlayer9.start();
                        currentPlaying = "MUSIC9";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC9 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC9",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music9");
                        }
                        break;

                    case "music10":
                        MediaPlayer mediaPlayer10 = MediaPlayer.create(getContext(), R.raw.music10);
                        mediaPlayer10.start();
                        currentPlaying = "MUSIC10";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC10 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC10",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music10");
                        }
                        break;
                    case "music11":
                        MediaPlayer mediaPlayer11 = MediaPlayer.create(getContext(), R.raw.music11);
                        mediaPlayer11.start();
                        currentPlaying = "MUSIC11";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC11 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC11",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music11");
                        }
                        break;

                    case "music12":
                        MediaPlayer mediaPlayer12 = MediaPlayer.create(getContext(), R.raw.music12);
                        mediaPlayer12.start();
                        currentPlaying = "MUSIC12";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC12 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC12",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music12");
                        }
                        break;
                    case "music13":
                        MediaPlayer mediaPlayer13 = MediaPlayer.create(getContext(), R.raw.music13);
                        mediaPlayer13.start();
                        currentPlaying = "MUSIC13";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC13 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC13",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music13");
                        }
                        break;

                    case "music14":
                        MediaPlayer mediaPlayer14 = MediaPlayer.create(getContext(), R.raw.music14);
                        mediaPlayer14.start();
                        currentPlaying = "MUSIC14";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC14 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC14",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music14");
                        }
                        break;
                    case "music15":
                        MediaPlayer mediaPlayer15 = MediaPlayer.create(getContext(), R.raw.music15);
                        mediaPlayer15.start();
                        currentPlaying = "MUSIC15";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC15 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC15",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music15");
                        }
                        break;

                    case "music16":
                        MediaPlayer mediaPlayer16 = MediaPlayer.create(getContext(), R.raw.music16);
                        mediaPlayer16.start();
                        currentPlaying = "MUSIC16";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC16 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC16",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music16");
                        }
                        break;
                    case "music17":
                        MediaPlayer mediaPlayer17 = MediaPlayer.create(getContext(), R.raw.music17);
                        mediaPlayer17.start();
                        currentPlaying = "MUSIC17";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC17 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC17",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music17");
                        }
                        break;

                    case "music18":
                        MediaPlayer mediaPlayer18 = MediaPlayer.create(getContext(), R.raw.music18);
                        mediaPlayer18.start();
                        currentPlaying = "MUSIC18";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC18 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC18",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music18");
                        }
                        break;
                    case "music19":
                        MediaPlayer mediaPlayer19 = MediaPlayer.create(getContext(), R.raw.music19);
                        mediaPlayer19.start();
                        currentPlaying = "MUSIC19";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC19 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC19",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music19");
                        }
                        break;

                    case "music20":
                        MediaPlayer mediaPlayer20 = MediaPlayer.create(getContext(), R.raw.music20);
                        mediaPlayer20.start();
                        currentPlaying = "MUSIC20";
                        if(list_fragment.dualPane ==true){
                        MainActivity.changeText.setText("MUSIC20 IS PLAYING");}
                        Toast.makeText(getContext(),"IS PLAYING MUSIC20",Toast.LENGTH_LONG).show();
                        if(button_triggered != null){

                            button_triggered.button_pressed("music20");
                        }
                        break;


                }


            }
        });


        return layout;

    }

   public interface button_pressed{
        public void button_pressed(String button_info);
    }

}
