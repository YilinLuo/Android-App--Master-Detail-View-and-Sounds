package com.example.ex_08;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class list_fragment extends ListFragment {

   public ArrayList list_buttons = new ArrayList();
   public Button button;
   public static Boolean dualPane;
   public showDetails callToDetail;
    public String TAG = "THE CLICKED BUTTON IS: ";

    public list_fragment(){

    }

    public static list_fragment newInstance() {

        list_fragment newFragment = new list_fragment();

        return newFragment;
    }

    @Override
    public void onCreate(Bundle state){
        super.onCreate(state);
        /****************************************************************************
         *
         * "setRetainInstance(true)" makes sure the screen orientation does not interrupt
         * the music playing.
         *
         ****************************************************************************/
        setRetainInstance(true);


        list_buttons.add(new buttons("music1"));
        list_buttons.add(new buttons("music2"));
        list_buttons.add(new buttons("music3"));
        list_buttons.add(new buttons("music4"));
        list_buttons.add(new buttons("music5"));
        list_buttons.add(new buttons("music6"));
        list_buttons.add(new buttons("music7"));
        list_buttons.add(new buttons("music8"));
        list_buttons.add(new buttons("music9"));
        list_buttons.add(new buttons("music10"));
        list_buttons.add(new buttons("music11"));
        list_buttons.add(new buttons("music12"));
        list_buttons.add(new buttons("music13"));
        list_buttons.add(new buttons("music14"));
        list_buttons.add(new buttons("music15"));
        list_buttons.add(new buttons("music16"));
        list_buttons.add(new buttons("music17"));
        list_buttons.add(new buttons("music18"));
        list_buttons.add(new buttons("music19"));
        list_buttons.add(new buttons("music20"));

        View displayFragment = getActivity().findViewById(R.id.details);
        dualPane = displayFragment != null && displayFragment.getVisibility() == View.VISIBLE;


        if(dualPane == true){
         if(callToDetail !=null){
             Log.d(TAG,"DUALPANE CALLING SHOWDETAILS");
            callToDetail.showDetails();}
        }

        Toast.makeText(getActivity(),"Dual pane is: "+ dualPane, Toast.LENGTH_LONG).show();

        customAdapter adapter = new customAdapter(getActivity(),list_buttons);
        setListAdapter(adapter);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.list_fragment,container,false);
        return v;
    }

    public interface showDetails{
        public void showDetails();
    }




}

